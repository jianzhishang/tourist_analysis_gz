import requests
import csv
from bs4 import BeautifulSoup
import re
from tqdm import tqdm
import time
from fake_useragent import UserAgent


# 随机生成 useragent
def get_random_useragent():
    ua = UserAgent()
    return ua.random


# 用于更新 headers
def update_headers(user_agent, cookie):
    headers = {
        "User-Agent": get_random_useragent(),
        "Cookie": cookie
    }
    return headers


# 获取评论
def get_comment(contents, re_, comment_list):
    comments = re_.finditer(contents)
    for comment_ in comments:
        raw_data = comment_.group("comment").strip()
        processed_data = re.sub(r"&#x0A;|&#x20;|<img.*?/>", "", raw_data)
        comment_list.append(processed_data)

    return comment_list


# 转换时间
def get_time(contents, re_, time_list):
    times = re_.finditer(contents)
    for time_ in times:
        raw_data = time_.group("time").strip()
        processed_data = re.sub(".*?更新于|' '", "", raw_data, flags=re.S)
        time_list.append(processed_data)

    return time_list


def load_comments(contents, re_1, re_2, re_3, re_4, csv_writer, key_word):
    # Step 1：获取评论内容的部分
    comment_list = []
    time_list = []
    # Step 2：获取 hide 的评论
    comment_list = get_comment(contents, re_1, comment_list)
    time_list = get_time(contents, re_2, time_list)
    # Step 3：获取未 hide 的评论
    comment_list = get_comment(contents, re_3, comment_list)
    time_list = get_time(contents, re_4, time_list)
    print(time_list)
    for comment_, time_ in zip(comment_list, time_list):
        csv_writer.writerow([key_word, time_, comment_])

    #time.sleep(1)

    return True


if __name__ == '__main__':
    # 定义参数
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0'
    cookie ='GSI=#rf_syztwlb@210720a#sl_zdjlwxbdsb@211011l#rf_syjgwlb@220829a#rf_tsmbyrk@220309b; _lxsdk_cuid=193a1101851c8-06a04ae66f8007-4c657b58-144000-193a1101851c8; _lxsdk=193a1101851c8-06a04ae66f8007-4c657b58-144000-193a1101851c8; _hc.v=d9981611-c767-7707-1873-2a1410165fff.1733574008; fspop=test; WEBDFPID=uz81v989v0915xzx18zw095u2uv81vu8806z8895z0297958864765v4-2048934019502-1733574018327GKCWIIMfd79fef3d01d5e9aadc18ccd4d0c95071620; ctu=0cae9b6a30724e4cd609b3d051bbd9fb74d38cac148f97694863a62690da63d9; Hm_lvt_602b80cf8079ae6591966cc70a3940e7=1733574044; HMACCOUNT=2F771AB2F9397B72; s_ViewType=10; __CACHE@is_login=true; logan_custom_report=; aburl=1; default_ab=shopreviewlist%3AA%3A1; cye=guangzhou; cy=1; Hm_lpvt_602b80cf8079ae6591966cc70a3940e7=1733578719; bingyingsearch_ab=citylist%3AA%3A1; _lx_utm=utm_source%3Dbing%26utm_medium%3Dorganic; cityid=4; cityname=%E5%B9%BF%E5%B7%9E; __CACHE@referer=https://www.dianping.com/search/keyword/4/0_%E5%A4%A7%E4%BD%9B%E5%8F%A4%E5%AF%BA; logan_session_token=1srjpog01ynk4wruk6vm; qruuid=5ef8189f-83ff-4575-b9d2-7915ca2c9eff; dplet=c66126f8b878aad123bf17c79b780f76; dper=0202951dec182525f945c6ed5ce713ea20463ddc83630fd166e5d761b7f56243f19d73c53ea834a70c3bb81e77154e4efa27aab48923012b26ab00000000f9240000190b1273134bef2cc46fa88d786812adde058ca4f9b54a409c9b25f70fe74c33f902a812e489a263367178530a3d61b2; ll=7fd06e815b796be3df069dec7836c3df; ua=%E7%82%B9%E5%B0%8F%E8%AF%845846976128; _lxsdk_s=193a1501d90-132-4dc-3ac%7C%7C4672'
    key_word = '大佛古寺'
    code = 'H3HWMCCIYQ69KVaj'
    min_num = 232
    max_num = 252
    headers = update_headers(user_agent, cookie)

    # 打开文件
    # TODO:修改成自己的文件地址
    f = open("./Big_Buddha_Temple.csv", mode="a+", encoding="utf-8")
    csv_writer = csv.writer(f)
    # 加载正则表达式，用于提取需要的信息
    re_1_comment = re.compile(r'<div class="review-words Hide">(?P<comment>.*?)<div class="less-words">', re.S)
    re_1_time = re.compile(r'<div class="review-words Hide">.*?<span class="time">(?P<time>.*?)</span>', re.S)
    re_2_comment = re.compile(r'<div class="review-words">(?P<comment>.*?)</div>', re.S)
    re_2_time = re.compile(r'<div class="review-words">.*?<span class="time">(?P<time>.*?)</span>', re.S)
    temp=0
    for i in tqdm(range(min_num, max_num)):
        temp +=1
        resp = requests.get(f"https://www.dianping.com/shop/{code}/review_all/p{i}", headers=headers)
        resp.encoding = "utf-8"
        contents = resp.text
        # store what I fetched
        load_comments(contents,
                      re_1=re_1_comment,
                      re_2=re_1_time,
                      re_3=re_2_comment,
                      re_4=re_2_time,
                      csv_writer=csv_writer,
                      key_word=key_word)
        if temp==10:
            temp=0
            time.sleep(10)
    f.close()