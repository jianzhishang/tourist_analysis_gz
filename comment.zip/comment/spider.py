import requests
import csv
from bs4 import BeautifulSoup
import re
from tqdm import tqdm
import time
from fake_useragent import UserAgent


# 用于更新 headers
def update_headers(user_agent, cookie):
    headers = {
        "User-Agent": user_agent,  # 直接使用用户输入的 user_agent
        "Cookie": cookie
    }
    return headers


# 获取评论及时间
def get_comment(contents, re_comment, re_time):
    comments = []
    times = []

    # 使用 finditer 进行匹配，确保捕获有效内容
    for comment_match, time_match in zip(re_comment.finditer(contents), re_time.finditer(contents)):
        try:
            # 使用 group() 获取捕获组
            raw_comment = comment_match.group("comment").strip() if comment_match else ""
            raw_time = time_match.group("time").strip() if time_match else ""

            # 对评论和时间进行处理
            processed_comment = re.sub(r"&#x0A;|&#x20;|<img.*?/>", "", raw_comment)
            processed_time = re.sub(".*?更新于|' '", "", raw_time, flags=re.S)

            # 添加到结果列表
            comments.append(processed_comment)
            times.append(processed_time)
        except AttributeError as e:
            # 如果捕获失败，打印错误并跳过
            print(f"AttributeError: {e}")
            continue

    return comments, times


def load_comments(contents, re_1, re_2, re_3, re_4, csv_writer, key_word):
    # 获取评论和时间
    comments, times = get_comment(contents, re_1, re_2)
    comments_2, times_2 = get_comment(contents, re_3, re_4)

    # 合并评论和时间
    comments.extend(comments_2)
    #times.extend(times_2)

    for comment, time in zip(comments, times):
        csv_writer.writerow([key_word, time, comment])

    time.sleep(5)  # 可调整延迟时间
    return True


if __name__ == '__main__':
    print("++")
    # 定义参数
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0'
    cookie = input("请输入cookie：")
    key_word = input("请输入评价的对象：")
    code = input("请输入code：")
    min_num = int(input("请输入最小页码："))
    max_num = int(input("请输入最大页码："))
    headers = update_headers(user_agent, cookie)


    # 打开文件
    with open("./Canton_Tower.csv", mode="w+", encoding="utf-8") as f:
        csv_writer = csv.writer(f)
        # 加载正则表达式，用于提取需要的信息
        re_1_comment = re.compile(r'<div class="review-words Hide">(?P<comment>.*?)<div class="less-words">', re.S)
        re_1_time = re.compile(r'<div class="review-words Hide">.*?<span class="time">(?P<time>.*?)</span>', re.S)
        re_2_comment = re.compile(r'<div class="review-words">(?P<comment>.*?)</div>', re.S)
        re_2_time = re.compile(r'<div class="review-words">.*?<span class="time">(?P<time>.*?)</span>', re.S)

        for i in tqdm(range(min_num, max_num)):
            try:
                resp = requests.get(f"https://www.dianping.com/shop/{code}/review_all/p{i}", headers=headers, timeout=10)
                resp.raise_for_status()  # 如果响应状态码是4xx或5xx，抛出异常
            except requests.RequestException as e:
                print(f"请求失败，错误信息: {e}")
                continue  # 出错时跳过当前页面，继续下一页

            contents = resp.text
            # store what I fetched
            load_comments(contents,
                          re_1=re_1_comment,
                          re_2=re_1_time,
                          re_3=re_2_comment,
                          re_4=re_2_time,
                          csv_writer=csv_writer,
                          key_word=key_word)
